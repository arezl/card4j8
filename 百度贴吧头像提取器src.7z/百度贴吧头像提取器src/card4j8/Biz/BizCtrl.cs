﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Collections.Generic;
using System.IO;
using TsubasaWing.App.TiebaCard.Draw;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Biz {

	/// <summary>
	/// 业务控制器
	/// </summary>
	public class BizCtrl {

		/// <summary>
		/// 运行参数
		/// </summary>
		public BizArgs Args { get; private set; }

		/// <summary>
		/// 画面上显示图片的方法
		/// </summary>
		public Action<string> _showPicture { private get; set; }

		/// <summary>
		/// 更新进度条的方法
		/// </summary>
		public Action<int, int> _updateProc { private get; set; }

		/// <summary>
		/// 初始化
		/// </summary>
		/// <param name="args">运行此参数</param>
		/// <param name="showPicture">画面上显示图片的函数</param>
		/// <param name="updateProc">更新进度条的函数</param>
		public BizCtrl(BizArgs args, Action<string> showPicture, Action<int, int> updateProc) {
			this.Args = args;
			this._showPicture = showPicture;
			this._updateProc = updateProc;
		}

		public void GetAll(Template template) {
			Printer.Message("正在获取吧友列表...");
			using(var tieba = new TiebaClient()) {
				// 获取用户列表
				List<UserInfo> userList =
						tieba.GetUserList(Args.TiebaName, Args.RankStart, Args.RankEnd);
				if(userList.Count == 0) {
					Printer.Error("无法获取吧友列表...请检查贴吧名是否正确");
					return;
				}
				Printer.Message("已获取 {0} ～ {1} 名吧友", Args.RankStart, Args.RankEnd);
				string saveDir = Args.Path + "\\" + Args.TiebaName;
				// 创建保存目录
				Directory.CreateDirectory(saveDir);
				// 清空保存目录
				foreach(string filePath in Directory.GetFiles(saveDir)) {
					File.Delete(filePath);
				}
				// 迭代所有用户取得头像
				Printer.Message("开始下载吧友头像...");
				foreach(var user in userList) {
					// 下载头像到本地
					tieba.DownloadUserImg(user, saveDir);
					// 设置用户路径
					template.Head.Path = user.ImagePath;
					// 使用模板创建用户卡片
					template.CreateCard(user);
					// 显示卡片
					_showPicture(user.ImagePath);
					Printer.Message(string.Format("{0}: {1} 头像下载成功", user.RankingString, user.Name));
					_updateProc(user.Ranking - Args.RankStart + 1, Args.Count);
				}
				// 生成大图
				if(Args.IsBig) {
					Printer.Message(string.Format("正在拼大图..."));
					ImageUtil.CreateBig(_updateProc, saveDir, Args.ColumnCount);
				}
				Printer.Message(string.Format("处理完成！！"));
			}
		}

		/// <summary>
		/// 窗口初始化时调用
		/// 获得所有模板信息
		/// </summary>
		/// <returns>模板信息列表</returns>
		public List<Template> GetTemplate() {
			var templateList = new List<Template>();
			templateList.Add(new Template());
			var templatePath = new DirectoryInfo(Consts.TEMPLATE_DIR_PATH);
			var templates = templatePath.GetDirectories();
			foreach(var templateDir in templates) {
				try {
					var template = new Template(templateDir.FullName);
					templateList.Add(template);
				} catch(Exception ex) {
					Printer.Error(ex);
					continue;
				}
			}
			return templateList;
		}
	}
}
