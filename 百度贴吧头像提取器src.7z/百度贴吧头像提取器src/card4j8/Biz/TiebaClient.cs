﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Net;
using System.Web;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Biz {

	/// <summary>
	/// 贴吧客户端
	/// 处理访问贴吧的各种操作
	/// </summary>
	public class TiebaClient : IDisposable {

		/// <summary>
		/// web访问器
		/// </summary>
		private WebClient _webClient = new WebClient() { Encoding = Consts.ENCODING};

		/// <summary>
		/// 根据贴吧名，获得吧友列表
		/// </summary>
		/// <param name="tiebaName">贴吧名</param>
		/// <param name="rankStart">排名开始</param>
		/// <param name="rankEnd">排名结束</param>
		/// <returns>吧友列表</returns>
		public List<UserInfo> GetUserList(string tiebaName, int rankStart, int rankEnd) {
			var userList = new List<UserInfo>();
			// 计算开始页与结束页
			int nowRank = rankStart;
			int startPage = rankStart / Consts.PAGE_SIZE + 1;
			int endPage = rankEnd / Consts.PAGE_SIZE;
			// 循环访问所有目标页获取吧友信息
			for(int page = startPage; page <= endPage; page++) {
				// 生成url
				string url = string.Format(Consts.USER_LIST_URL,
						HttpUtility.UrlEncode(tiebaName, Consts.ENCODING), page);
				// 获取html
				string html = _webClient.DownloadString(url);
				// 获取当页吧友列表
				var pageUserList = _parseRankingPageHtml(ref nowRank, html);
				// 添加到吧友列表
				userList.AddRange(pageUserList);
				// 末页，或者贴解析错误
				if(pageUserList.Count != Consts.PAGE_SIZE) {
					return userList;
				}
			}
			return userList;
		}

		/// <summary>
		/// 从排名页html中解析用户信息
		/// </summary>
		/// <param name="nowRank">排名（引用传递）</param>
		/// <param name="html">排名html</param>
		/// <returns>该页用户信息(一般情况为20)</returns>
		private List<UserInfo> _parseRankingPageHtml(ref int nowRank, string html) {
			var pageUserList = new List<UserInfo>();
			var doc = new HtmlDocument();
			try {
				doc.LoadHtml(html);
				var userNodes = doc.DocumentNode.SelectNodes("//tr[@class=\"drl_list_item\"]");
				foreach(var userNode in userNodes) {
					UserInfo user = new UserInfo() { Ranking = nowRank++ };
					var nameNode = userNode.SelectSingleNode(
							"./td[@class=\"drl_item_name\"]/div/a");
					var expNode = userNode.SelectSingleNode(
							"./td[@class=\"drl_item_exp\"]/span");
					user.HomeUrl = Consts.TIEBA_URL + nameNode.Attributes["href"].Value;
					user.NameCode = nameNode.Attributes["username"].Value;
					user.Exp = int.Parse(expNode.InnerText);
					pageUserList.Add(user);
				}
				return pageUserList;
			} catch {
				return pageUserList;
			}
		}

		/// <summary>
		/// 下载用户图片
		/// </summary>
		/// <param name="homeUrl">用户主页地址</param>
		/// <param name="imgUrl">头像地址</param>
		/// <returns>用户头像本地路径</returns>
		public void DownloadUserImg(UserInfo user, string path) {
			try {
				string html = _webClient.DownloadString(user.HomeUrl);
				var doc = new HtmlDocument();
				doc.LoadHtml(html);
				var userNode = doc.GetElementbyId("userinfo_wrap");
				var imgNode = userNode.SelectSingleNode("//div/div/a/img");
				// 用户头像地址
				string imgUrl = imgNode.Attributes["src"].Value;
				// 文件名
				string fileName = string.Format("{0}_{1}{2}", user.RankingString, user.Name, Consts.IMAGE_EXT);
				// 本地保存路径
				string imgPath = path + "\\" + fileName;
				// 下载
				_webClient.DownloadFile(imgUrl, imgPath);
				// 设置用户头像路径
				user.ImagePath = imgPath;
			} catch(Exception ex) {
				Printer.Debug(ex);
				user.ImagePath = string.Empty;
			}
		}

		/// <summary>
		/// 释放
		/// using语句专用
		/// </summary>
		public void Dispose() {
			try {
				_webClient.Dispose();
			} catch(Exception ex) {
				_webClient = null;
				Printer.Error(ex);
			}
		}
	}
}
