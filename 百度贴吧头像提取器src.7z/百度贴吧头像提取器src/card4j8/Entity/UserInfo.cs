﻿using System;
// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Web;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Entity {

	/// <summary>
	/// 用户信息
	/// </summary>
	public class UserInfo {
		
		/// <summary>
		/// 反射获取用户属性
		/// </summary>
		/// <param name="PropertyName">属性名</param>
		/// <returns>属性值</returns>
		public object this[string PropertyName] { 
			get {
				try {
					return GetType().GetProperty(PropertyName).GetValue(this, null);
				} catch(Exception ex) {
					Printer.Error(ex);
					return null;
				}
			}
		}

		private string _name = string.Empty;
		public string Name {
			get {
				return _name;
			}
			set {
				_name = value;
				_nameCode = HttpUtility.UrlEncode(value, Consts.ENCODING);
			}
		}

		private string _nameCode = string.Empty;
		public string NameCode {
			get {
				return _nameCode;
			}
			set {
				_name = HttpUtility.UrlDecode(value, Consts.ENCODING);
				_name.Replace("\r\n", string.Empty).Replace("\n", string.Empty);
				_nameCode = value;
			}
		}

		/// <summary>
		/// 用户经验
		/// </summary>
		public int Exp { get; set; }

		/// <summary>
		/// 用户等级
		/// </summary>
		public int Lv { get{
			for(int lv = 0; lv < Consts.TIEBA_EXP_LIST.Length; lv++) {
				if(Exp < Consts.TIEBA_EXP_LIST[lv]) {
					return lv;
				}
			}
			return 0;
		} }

		/// <summary>
		/// 用户排名
		/// </summary>
		public int Ranking { get; set; }

		/// <summary>
		/// 排名左填充
		/// </summary>
		public string RankingString {
			get {
				return Ranking.ToString("#000");
			}
		}

		/// <summary>
		/// 本地保存地址
		/// </summary>
		public string ImagePath { get; set; }

		/// <summary>
		/// 用户主页地址
		/// </summary>
		public string HomeUrl { get; set; }

	}
}
