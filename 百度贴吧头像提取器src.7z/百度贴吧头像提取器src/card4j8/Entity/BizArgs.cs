﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Entity {
	
	/// <summary>
	/// 运行参数
	/// </summary>
	[Serializable]
	public class BizArgs {

		/// <summary>
		/// 是否生成大图
		/// </summary>
		public bool IsBig { get; set; }

		/// <summary>
		/// 图片列数
		/// </summary>
		public int ColumnCount { get; set; }

		/// <summary>
		/// 保存路径
		/// </summary>
		public string Path { get; set; }

		/// <summary>
		/// 贴吧名
		/// </summary>
		public string TiebaName { get; set; }

		/// <summary>
		/// 排名开始
		/// </summary>
		public int RankStart { get; set; }

		/// <summary>
		/// 排名结束
		/// </summary>
		public int RankEnd { get; set; }

		/// <summary>
		/// 获取总数
		/// </summary>
		public int Count {
			get {
				return RankEnd - RankStart + 1;
			}
		}

		/// <summary>
		/// 私有构造器
		/// </summary>
		private BizArgs() { }

		/// <summary>
		/// 单例
		/// </summary>
		private static BizArgs _ARGS = null;

		/// <summary>
		/// 保存路径
		/// </summary>
		private const string PATH = "setting.obj";

		/// <summary>
		/// 读取运行参数
		/// </summary>
		/// <returns>获得对象</returns>
		public static BizArgs Load() {
			try {
				IFormatter formatter = new BinaryFormatter();
				using(Stream stream = new FileStream(PATH, FileMode.Open, FileAccess.Read, FileShare.Read)) {
					_ARGS = (BizArgs)formatter.Deserialize(stream);
				}
			} catch {
				_ARGS = new BizArgs {
					IsBig = false,
					ColumnCount = 4,
					Path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
					TiebaName = "java",
					RankStart = 1,
					RankEnd = 20
				};
			}
			return _ARGS;
		}

		/// <summary>
		/// 保存运行参数
		/// </summary>
		public static void Save() {
			try {
				IFormatter formatter = new BinaryFormatter();
				using(Stream stream = new FileStream(PATH, FileMode.Create, FileAccess.Write, FileShare.None)) {
					formatter.Serialize(stream, _ARGS);
				}
			} catch(Exception ex) {
				Printer.Error(ex);
			}
		}

	}
}
