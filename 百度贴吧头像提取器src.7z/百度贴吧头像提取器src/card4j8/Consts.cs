﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Text;

namespace TsubasaWing.App.TiebaCard {
	
	/// <summary>
	/// 常量
	/// </summary>
	public static class Consts {

		/// <summary>
		/// 版本号
		/// </summary>
		public const string VERSION = "ver1.0";

		/// <summary>
		/// 是否输出调试信息
		/// </summary>
		public const bool DEBUG = false;

		/// <summary>
		/// 贴吧默认编码
		/// </summary>
		public static readonly Encoding ENCODING = Encoding.GetEncoding("gbk");

		/// <summary>
		/// 贴吧地址
		/// </summary>
		public const string TIEBA_URL = "http://tieba.baidu.com";

		/// <summary>
		/// 用户排名页面url
		/// </summary>
		public const string USER_LIST_URL = TIEBA_URL + "/f/like/furank?kw={0}&pn={1}";

		/// <summary>
		/// 用户主页url
		/// </summary>
		public const string IMAGE_EXT = ".jpg";

		/// <summary>
		/// 模板保存路径
		/// </summary>
		public const string TEMPLATE_DIR_PATH = @"templates\";

		/// <summary>
		/// 模板配置文件名
		/// </summary>
		public const string TEMPLATE_CONFIG_FILE_PATH = "config.xml";
		
		/// <summary>
		/// 经验页面用户数
		/// </summary>
		public const int PAGE_SIZE = 20;

		/// <summary>
		/// 一次最大用户数
		/// </summary>
		public const int MAX_USER = 100;

		/// <summary>
		/// 经验列表（计算等级用）
		/// </summary>
		public static readonly int[] TIEBA_EXP_LIST = {
			1, 5, 15, 30, 50, 100, 200, 500, 1000, 2000, 3000,
			6000, 10000, 18000, 30000, 60000, 100000, 300000
		};
	}
}
