﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Xml.Linq;

namespace TsubasaWing.App.TiebaCard.Util {
	
	/// <summary>
	/// 
	/// </summary>
	public static class XmlHelper {
		
		public static string GetString(this XElement elm, string key, string nullValue = "") {
			XAttribute atb = elm.Attribute(key);
			return atb == null ? nullValue : atb.Value;
		}

		public static int GetInt(this XElement elm, string key, int exValue = 0) {
			try {
				return int.Parse(elm.Attribute(key).Value);
			} catch(Exception) {
				return exValue;
			}
		}

		public static bool GetBool(this XElement elm, string key) {
			try {
				return bool.Parse(elm.Attribute(key).Value);
			} catch(Exception) {
				return false;
			}
		}
	}
}
