﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Drawing;
using System.IO;

namespace TsubasaWing.App.TiebaCard.Util {
	
	/// <summary>
	/// 图片显示工具类
	/// </summary>
	public static class ImageUtil {
		
		/// <summary>
		/// 将图片读取至内存，并释放文件
		/// </summary>
		/// <param name="path">路径</param>
		/// <returns>读取的图片</returns>
		public static Image ReadImage(string path) {
			try {
				using(FileStream stream = new FileStream(path, FileMode.Open)) {
					byte[] b = new byte[stream.Length];
					stream.Read(b, 0, b.Length);
					return Image.FromStream(new MemoryStream(b));
				}
			} catch {
				return null;
			}
		}

		/// <summary>
		/// 生成大图
		/// </summary>
		/// <param name="_updateProc"></param>
		/// <param name="saveDir"></param>
		/// <param name="columnCount"></param>
		public static void CreateBig(
				Action<int, int> _updateProc, string saveDir, int columnCount) {
			string[] imgPathes = Directory.GetFiles(saveDir, "*" + Consts.IMAGE_EXT);
			// 以第一张图片为准
			Image firstImage = ReadImage(imgPathes[0]);
			int imgW = firstImage.Width;
			int imgH = firstImage.Height;
			// 创建大图
			Bitmap bigMap = new Bitmap(
				// 大图宽度
				imgW * columnCount,
				// 大图高度（分页算法，不解释）
				imgH * Math.Max(((imgPathes.Length + columnCount - 1) / columnCount), 1)
			);
			Graphics g = Graphics.FromImage(bigMap);
			for(int i = 0; i < imgPathes.Length; i++) {
				Image img = ReadImage(imgPathes[i]);
				g.DrawImage(new Bitmap(img),
					(i % columnCount) * imgW,
					(i / columnCount) * imgH, 
					imgW, imgH);
				_updateProc(i + 1, imgPathes.Length);
			}
			bigMap.Save(saveDir + "\\big.png");
		}
	}
}
