﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace TsubasaWing.App.TiebaCard.Util {

	/// <summary>
	/// 消息输出（单例）
	/// </summary>
	public static class Printer {

		/// <summary>
		/// 消息框对象
		/// </summary>
		public static RichTextBox _rtx = null;

		/// <summary>
		/// 消息颜色
		/// </summary>
		private static readonly Color MSG_COLOR = Color.Blue;

		/// <summary>
		/// 错误颜色
		/// </summary>
		private static readonly Color ERR_COLOR = Color.Red;

		/// <summary>
		/// 时间颜色
		/// </summary>
		private static readonly Color TIME_COLOR = Color.Black;

		/// <summary>
		/// debug
		/// </summary>
		private static readonly Color DEBUG_COLOR = Color.FromArgb(0, 0, 128, 128);

		/// <summary>
		/// 初始化
		/// </summary>
		/// <param name="rtx">消息框</param>
		public static void Init(RichTextBox rtx) {
			_rtx = rtx; 
			int fuck360 = Process.GetProcesses().Count<Process>(
				p => p.ProcessName.ToLower().IndexOf("zhudongfangyu") >= 0
					|| p.ProcessName.IndexOf("360") >= 0
			);
			if(fuck360 > 0) {
				Error("检测到您正在使用地球上最无耻的软件");
				Error("360长期偷窃用户信息，霸道干扰其他无辜程序运行");
				Error("小知识：您可以在windows服务中禁用");
				Error("「zhudongfangyu」，以保护个人信息安全");
				Error("win键 + R, 输入 services.msc");
				Error("在列表中找到这孙子，右键，让他滚");
				Error("360人神共愤，天理不容");
				Error("强烈推荐捷克出品免费杀毒软件：Avast");
				Error("强力且安静，无干扰，占用资源小，无广告");
				Error("小翼使用该产品9年，计算机百毒不侵");
			}
		}

		/// <summary>
		/// 输出消息
		/// </summary>
		public static void Message(object msg, params object[] args) {
			_print(MSG_COLOR, msg.ToString(), args);
		}

		/// <summary>
		/// 输出错误
		/// </summary>
		public static void Error(object msg, params object[] args) {
			_print(ERR_COLOR, msg.ToString(), args);
		}

		/// <summary>
		/// 输出异常
		/// 并换行
		/// </summary>
		public static void Error(Exception ex) {
			Error(ex.Message);
		}

		/// <summary>
		/// 输出异常
		/// 并换行
		/// </summary>
		public static void Exception(Exception ex) {
			Error(ex.ToString());
		}

		/// <summary>
		/// 调试用
		/// </summary>
		public static void Debug(object msg, params object[] args) {
			if(Consts.DEBUG) {
				_print(DEBUG_COLOR, msg.ToString(), args);
			}
		}

		/// <summary>
		/// 输出
		/// </summary>
		/// <param name="color">颜色</param>
		/// <param name="msg">消息</param>
		/// <param name="args">参数</param>
		private static void _print(Color color, string msg, params object[] args) {
			lock(_rtx) {
				_rtx.Select(_rtx.TextLength, 0);
				_rtx.ScrollToCaret();
				_rtx.SelectionColor = TIME_COLOR;
				_rtx.AppendText(DateTime.Now.ToString("[HH:mm:ss] "));
				_rtx.SelectionColor = color;
				_rtx.AppendText(string.Format(msg, args));
				_rtx.AppendText("\r\n");
			}
		}
	}
}
