﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Threading;
using System.Windows.Forms;
using TsubasaWing.App.TiebaCard.Biz;
using TsubasaWing.App.TiebaCard.Draw;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Gui {

	public partial class FrmMain : Form {

		/// <summary>
		/// 业务对象
		/// </summary>
		private BizCtrl _biz = null;

		/// <summary>
		/// 初始化
		/// </summary>
		public FrmMain() {
			// 控件初始化
			InitializeComponent();
			// 消息输出工具初始化
			Printer.Init(RtxMessage);
			// 版本号
			TxtVersion.Text = Consts.VERSION;
			// 读取配置
			BizArgs args = BizArgs.Load();
			// 初始化业务对象
			_biz = new BizCtrl(args, _showPicture, _updateProc);
			// 贴吧名
			TxtTiebaName.Text = args.TiebaName;
			// 开始排名
			NumRankStart.Value = args.RankStart;
			// 结束排名
			NumRankEnd.Value = args.RankEnd;
			// 是否拼大图
			ChkBig.Checked = args.IsBig;
			// 大图每行几张
			NumColumnCount.Value = args.ColumnCount;
			// 保存路径
			TxtPath.Text = args.Path;
			// 模板
			var templateList = _biz.GetTemplate();
			CbxTemplate.Items.AddRange(templateList.ToArray());
			CbxTemplate.SelectedIndex = 0;
		}

		/// <summary>
		/// 设置界面值
		/// </summary>
		/// <param name="args">运行参数</param>
		private void _setUiArgs() {
			TxtPath.Text = _biz.Args.Path;
			TxtTiebaName.Text = _biz.Args.TiebaName;
			ChkBig.Checked = _biz.Args.IsBig;
			NumColumnCount.Value = _biz.Args.ColumnCount;
			NumRankEnd.Value = _biz.Args.RankEnd;
			NumRankStart.Value = _biz.Args.RankStart;
		}

		/// <summary>
		/// 设置运行参数
		/// </summary>
		private void _setBizArgs() {
			_biz.Args.Path = TxtPath.Text;
			_biz.Args.TiebaName = TxtTiebaName.Text;
			_biz.Args.IsBig = ChkBig.Checked;
			_biz.Args.ColumnCount = (int)NumColumnCount.Value;
			_biz.Args.RankEnd = (int)NumRankEnd.Value;
			_biz.Args.RankStart = (int)NumRankStart.Value;
			BizArgs.Save();
		}

		/// <summary>
		/// 获取按钮按下时
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void BtnGetAll_Click(object sender, EventArgs e) {
			// 清空消息框
			RtxMessage.Clear();
			// 获取界面参数
			_setBizArgs();
			// 控件关闭
			_controlSwitch(false);
			// 获得用户选择模板
			Template template = (Template)CbxTemplate.SelectedItem;
			// 新建线程获取用户信息
			new Thread(new ThreadStart(() => {
				try {
					// 获取用户信息
					_biz.GetAll(template);
				} catch(Exception ex) {
					Printer.Exception(ex);
				} finally {
					// 控件开启
					_controlSwitch(true);
				}
			})) {
				// 后台线程
				IsBackground = true
			}.Start();
		}

		private void BtnDir_Click(object sender, EventArgs e) {
			DialogResult res = FbrDir.ShowDialog();
			if(res == DialogResult.OK) {
				TxtPath.Text = FbrDir.SelectedPath;
			}
		}

		private void CbxTemplate_SelectedIndexChanged(object sender, EventArgs e) {
			Template template = (Template)CbxTemplate.SelectedItem;
			if(template != null) {
				PicCard.Image = template.CreateCard();
			}
		}

		/// <summary>
		/// 窗口可操作性
		/// </summary>
		/// <param name="on"></param>
		private void _controlSwitch(bool on) {
			CbxTemplate.Enabled = on;
			ChkBig.Enabled = on;
			NumColumnCount.Enabled = on;
			TxtPath.Enabled = on;
			BtnDir.Enabled = on;
			TxtTiebaName.Enabled = on;
			BtnGetAll.Enabled = on;
			NumRankStart.Enabled = on;
			NumRankEnd.Enabled = on;
			// 运行时，关闭界面线程安全性检查
			Form.CheckForIllegalCrossThreadCalls = on;
		}

		/// <summary>
		/// 更新进度条
		/// </summary>
		/// <param name="value"></param>
		/// <param name="max"></param>
		private void _updateProc(int value, int max) {
			max = max < 1 ? 1 : max;
			value = value > max ? max : value;
			lock(ProcBar) {
				ProcBar.Maximum = max;
				ProcBar.Value = value;
				Application.DoEvents();
			}
		}

		/// <summary>
		/// 显示图片
		/// </summary>
		/// <param name="path">图片路径</param>
		private void _showPicture(string path) {
			lock(PicCard) {
				PicCard.Image = ImageUtil.ReadImage(path);
			}
		}

		/// <summary>
		/// 验证数值
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void NumRank_ValueChanged(object sender, EventArgs e) {
			if(NumRankStart.Value >= NumRankEnd.Value) {
				NumRankEnd.Value = NumRankStart.Value + Consts.PAGE_SIZE - 1;
			}
			if(NumRankEnd.Value - NumRankStart.Value > Consts.MAX_USER) {
				NumRankEnd.Value = NumRankStart.Value + Consts.MAX_USER - 1;
			}
		}
	}
}