﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。

namespace TsubasaWing.App.TiebaCard.Gui {
	partial class FrmMain {
		/// <summary>
		/// 必需的设计器变量。
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// 清理所有正在使用的资源。
		/// </summary>
		/// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
		protected override void Dispose(bool disposing) {
			if(disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows 窗体设计器生成的代码

		/// <summary>
		/// 设计器支持所需的方法 - 不要
		/// 使用代码编辑器修改此方法的内容。
		/// </summary>
		private void InitializeComponent() {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
			this.GrpGetAll = new System.Windows.Forms.GroupBox();
			this.TxtTiebaName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.LabTieba = new System.Windows.Forms.Label();
			this.TxtPath = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.NumRankStart = new System.Windows.Forms.NumericUpDown();
			this.NumRankEnd = new System.Windows.Forms.NumericUpDown();
			this.label6 = new System.Windows.Forms.Label();
			this.BtnGetAll = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.BtnDir = new System.Windows.Forms.Button();
			this.NumColumnCount = new System.Windows.Forms.NumericUpDown();
			this.CbxTemplate = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.ChkBig = new System.Windows.Forms.CheckBox();
			this.PicCard = new System.Windows.Forms.PictureBox();
			this.GrpMessage = new System.Windows.Forms.GroupBox();
			this.ProcBar = new System.Windows.Forms.ProgressBar();
			this.RtxMessage = new System.Windows.Forms.RichTextBox();
			this.GrpView = new System.Windows.Forms.GroupBox();
			this.FbrDir = new System.Windows.Forms.FolderBrowserDialog();
			this.StsAbout = new System.Windows.Forms.StatusStrip();
			this.TxtVersion = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.TxtAuthor = new System.Windows.Forms.ToolStripStatusLabel();
			this.TxtDate = new System.Windows.Forms.ToolStripStatusLabel();
			this.TxtAbout = new System.Windows.Forms.ToolStripStatusLabel();
			this.GrpGetAll.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumRankStart)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumRankEnd)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NumColumnCount)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PicCard)).BeginInit();
			this.GrpMessage.SuspendLayout();
			this.GrpView.SuspendLayout();
			this.StsAbout.SuspendLayout();
			this.SuspendLayout();
			// 
			// GrpGetAll
			// 
			this.GrpGetAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.GrpGetAll.Controls.Add(this.TxtTiebaName);
			this.GrpGetAll.Controls.Add(this.label2);
			this.GrpGetAll.Controls.Add(this.LabTieba);
			this.GrpGetAll.Controls.Add(this.TxtPath);
			this.GrpGetAll.Controls.Add(this.label3);
			this.GrpGetAll.Controls.Add(this.NumRankStart);
			this.GrpGetAll.Controls.Add(this.NumRankEnd);
			this.GrpGetAll.Controls.Add(this.label6);
			this.GrpGetAll.Controls.Add(this.BtnGetAll);
			this.GrpGetAll.Controls.Add(this.label1);
			this.GrpGetAll.Controls.Add(this.BtnDir);
			this.GrpGetAll.Controls.Add(this.NumColumnCount);
			this.GrpGetAll.Controls.Add(this.CbxTemplate);
			this.GrpGetAll.Controls.Add(this.label5);
			this.GrpGetAll.Controls.Add(this.ChkBig);
			this.GrpGetAll.Location = new System.Drawing.Point(16, 433);
			this.GrpGetAll.Margin = new System.Windows.Forms.Padding(4);
			this.GrpGetAll.Name = "GrpGetAll";
			this.GrpGetAll.Padding = new System.Windows.Forms.Padding(4);
			this.GrpGetAll.Size = new System.Drawing.Size(501, 134);
			this.GrpGetAll.TabIndex = 300;
			this.GrpGetAll.TabStop = false;
			this.GrpGetAll.Text = "设定";
			// 
			// TxtTiebaName
			// 
			this.TxtTiebaName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.TxtTiebaName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.TxtTiebaName.Location = new System.Drawing.Point(8, 100);
			this.TxtTiebaName.Margin = new System.Windows.Forms.Padding(4);
			this.TxtTiebaName.MaxLength = 16;
			this.TxtTiebaName.Name = "TxtTiebaName";
			this.TxtTiebaName.Size = new System.Drawing.Size(116, 22);
			this.TxtTiebaName.TabIndex = 350;
			this.TxtTiebaName.Text = "java";
			this.TxtTiebaName.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(8, 68);
			this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(37, 15);
			this.label2.TabIndex = 4;
			this.label2.Text = "路径";
			// 
			// LabTieba
			// 
			this.LabTieba.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.LabTieba.AutoSize = true;
			this.LabTieba.Location = new System.Drawing.Point(133, 104);
			this.LabTieba.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.LabTieba.Name = "LabTieba";
			this.LabTieba.Size = new System.Drawing.Size(22, 15);
			this.LabTieba.TabIndex = 7;
			this.LabTieba.Text = "吧";
			// 
			// TxtPath
			// 
			this.TxtPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.TxtPath.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.TxtPath.ForeColor = System.Drawing.Color.Black;
			this.TxtPath.Location = new System.Drawing.Point(52, 64);
			this.TxtPath.Margin = new System.Windows.Forms.Padding(4);
			this.TxtPath.Name = "TxtPath";
			this.TxtPath.ReadOnly = true;
			this.TxtPath.Size = new System.Drawing.Size(333, 22);
			this.TxtPath.TabIndex = 5;
			this.TxtPath.TabStop = false;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(248, 104);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(22, 15);
			this.label3.TabIndex = 8;
			this.label3.Text = "到";
			// 
			// NumRankStart
			// 
			this.NumRankStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
			this.NumRankStart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.NumRankStart.Increment = new decimal(new int[] {
            20,
            0,
            0,
            0});
			this.NumRankStart.Location = new System.Drawing.Point(164, 100);
			this.NumRankStart.Margin = new System.Windows.Forms.Padding(4);
			this.NumRankStart.Maximum = new decimal(new int[] {
            49981,
            0,
            0,
            0});
			this.NumRankStart.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NumRankStart.Name = "NumRankStart";
			this.NumRankStart.ReadOnly = true;
			this.NumRankStart.Size = new System.Drawing.Size(77, 22);
			this.NumRankStart.TabIndex = 360;
			this.NumRankStart.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NumRankStart.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NumRankStart.ValueChanged += new System.EventHandler(this.NumRank_ValueChanged);
			// 
			// NumRankEnd
			// 
			this.NumRankEnd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.NumRankEnd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.NumRankEnd.Increment = new decimal(new int[] {
            20,
            0,
            0,
            0});
			this.NumRankEnd.Location = new System.Drawing.Point(279, 100);
			this.NumRankEnd.Margin = new System.Windows.Forms.Padding(4);
			this.NumRankEnd.Maximum = new decimal(new int[] {
            50000,
            0,
            0,
            0});
			this.NumRankEnd.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
			this.NumRankEnd.Name = "NumRankEnd";
			this.NumRankEnd.ReadOnly = true;
			this.NumRankEnd.Size = new System.Drawing.Size(77, 22);
			this.NumRankEnd.TabIndex = 370;
			this.NumRankEnd.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NumRankEnd.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
			this.NumRankEnd.ValueChanged += new System.EventHandler(this.NumRank_ValueChanged);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(364, 104);
			this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(22, 15);
			this.label6.TabIndex = 9;
			this.label6.Text = "名";
			// 
			// BtnGetAll
			// 
			this.BtnGetAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.BtnGetAll.Location = new System.Drawing.Point(395, 98);
			this.BtnGetAll.Margin = new System.Windows.Forms.Padding(4);
			this.BtnGetAll.Name = "BtnGetAll";
			this.BtnGetAll.Size = new System.Drawing.Size(99, 29);
			this.BtnGetAll.TabIndex = 380;
			this.BtnGetAll.Text = "取得";
			this.BtnGetAll.UseVisualStyleBackColor = true;
			this.BtnGetAll.Click += new System.EventHandler(this.BtnGetAll_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(431, 29);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(55, 15);
			this.label1.TabIndex = 3;
			this.label1.Text = "张 / 行";
			// 
			// BtnDir
			// 
			this.BtnDir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.BtnDir.Location = new System.Drawing.Point(395, 64);
			this.BtnDir.Margin = new System.Windows.Forms.Padding(4);
			this.BtnDir.Name = "BtnDir";
			this.BtnDir.Size = new System.Drawing.Size(99, 29);
			this.BtnDir.TabIndex = 340;
			this.BtnDir.Text = "浏览";
			this.BtnDir.UseVisualStyleBackColor = true;
			this.BtnDir.Click += new System.EventHandler(this.BtnDir_Click);
			// 
			// NumColumnCount
			// 
			this.NumColumnCount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.NumColumnCount.Location = new System.Drawing.Point(368, 24);
			this.NumColumnCount.Margin = new System.Windows.Forms.Padding(4);
			this.NumColumnCount.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
			this.NumColumnCount.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.NumColumnCount.Name = "NumColumnCount";
			this.NumColumnCount.ReadOnly = true;
			this.NumColumnCount.Size = new System.Drawing.Size(56, 22);
			this.NumColumnCount.TabIndex = 330;
			this.NumColumnCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.NumColumnCount.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
			// 
			// CbxTemplate
			// 
			this.CbxTemplate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.CbxTemplate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.CbxTemplate.FormattingEnabled = true;
			this.CbxTemplate.Location = new System.Drawing.Point(52, 25);
			this.CbxTemplate.Margin = new System.Windows.Forms.Padding(4);
			this.CbxTemplate.Name = "CbxTemplate";
			this.CbxTemplate.Size = new System.Drawing.Size(203, 23);
			this.CbxTemplate.TabIndex = 310;
			this.CbxTemplate.SelectedIndexChanged += new System.EventHandler(this.CbxTemplate_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(8, 29);
			this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(37, 15);
			this.label5.TabIndex = 1;
			this.label5.Text = "模板";
			// 
			// ChkBig
			// 
			this.ChkBig.AutoSize = true;
			this.ChkBig.Location = new System.Drawing.Point(264, 28);
			this.ChkBig.Margin = new System.Windows.Forms.Padding(4);
			this.ChkBig.Name = "ChkBig";
			this.ChkBig.Size = new System.Drawing.Size(89, 19);
			this.ChkBig.TabIndex = 320;
			this.ChkBig.Text = "生成大图";
			this.ChkBig.UseVisualStyleBackColor = true;
			// 
			// PicCard
			// 
			this.PicCard.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.PicCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.PicCard.Location = new System.Drawing.Point(15, 25);
			this.PicCard.Margin = new System.Windows.Forms.Padding(11, 5, 11, 5);
			this.PicCard.Name = "PicCard";
			this.PicCard.Size = new System.Drawing.Size(435, 518);
			this.PicCard.TabIndex = 6;
			this.PicCard.TabStop = false;
			// 
			// GrpMessage
			// 
			this.GrpMessage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
			this.GrpMessage.Controls.Add(this.ProcBar);
			this.GrpMessage.Controls.Add(this.RtxMessage);
			this.GrpMessage.Location = new System.Drawing.Point(16, 15);
			this.GrpMessage.Margin = new System.Windows.Forms.Padding(4);
			this.GrpMessage.Name = "GrpMessage";
			this.GrpMessage.Padding = new System.Windows.Forms.Padding(4);
			this.GrpMessage.Size = new System.Drawing.Size(501, 410);
			this.GrpMessage.TabIndex = 200;
			this.GrpMessage.TabStop = false;
			this.GrpMessage.Text = "消息";
			// 
			// ProcBar
			// 
			this.ProcBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.ProcBar.Location = new System.Drawing.Point(8, 382);
			this.ProcBar.Margin = new System.Windows.Forms.Padding(4);
			this.ProcBar.Name = "ProcBar";
			this.ProcBar.Size = new System.Drawing.Size(485, 20);
			this.ProcBar.TabIndex = 9;
			// 
			// RtxMessage
			// 
			this.RtxMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.RtxMessage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
			this.RtxMessage.Location = new System.Drawing.Point(8, 25);
			this.RtxMessage.Margin = new System.Windows.Forms.Padding(4);
			this.RtxMessage.Name = "RtxMessage";
			this.RtxMessage.ReadOnly = true;
			this.RtxMessage.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedBoth;
			this.RtxMessage.Size = new System.Drawing.Size(484, 349);
			this.RtxMessage.TabIndex = 210;
			this.RtxMessage.TabStop = false;
			this.RtxMessage.Text = "";
			// 
			// GrpView
			// 
			this.GrpView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.GrpView.Controls.Add(this.PicCard);
			this.GrpView.Location = new System.Drawing.Point(525, 15);
			this.GrpView.Margin = new System.Windows.Forms.Padding(4);
			this.GrpView.Name = "GrpView";
			this.GrpView.Padding = new System.Windows.Forms.Padding(4);
			this.GrpView.Size = new System.Drawing.Size(464, 552);
			this.GrpView.TabIndex = 100;
			this.GrpView.TabStop = false;
			this.GrpView.Text = "预览";
			// 
			// StsAbout
			// 
			this.StsAbout.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TxtVersion,
            this.toolStripStatusLabel1,
            this.TxtAuthor,
            this.TxtDate,
            this.TxtAbout});
			this.StsAbout.Location = new System.Drawing.Point(0, 569);
			this.StsAbout.Name = "StsAbout";
			this.StsAbout.Size = new System.Drawing.Size(1006, 24);
			this.StsAbout.TabIndex = 301;
			this.StsAbout.Text = "statusStrip1";
			// 
			// TxtVersion
			// 
			this.TxtVersion.Name = "TxtVersion";
			this.TxtVersion.Size = new System.Drawing.Size(0, 19);
			this.TxtVersion.ToolTipText = "VerX.X";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 19);
			// 
			// TxtAuthor
			// 
			this.TxtAuthor.Name = "TxtAuthor";
			this.TxtAuthor.Size = new System.Drawing.Size(84, 19);
			this.TxtAuthor.Text = "作者：小翼";
			// 
			// TxtDate
			// 
			this.TxtDate.Name = "TxtDate";
			this.TxtDate.Size = new System.Drawing.Size(70, 19);
			this.TxtDate.Text = "2014-02";
			// 
			// TxtAbout
			// 
			this.TxtAbout.Name = "TxtAbout";
			this.TxtAbout.Size = new System.Drawing.Size(575, 19);
			this.TxtAbout.Text = "声明：该工具以及源码不得用于学习以外的其他任何目的。重新编译请保留版权信息。";
			// 
			// FrmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.ClientSize = new System.Drawing.Size(1006, 593);
			this.Controls.Add(this.StsAbout);
			this.Controls.Add(this.GrpView);
			this.Controls.Add(this.GrpMessage);
			this.Controls.Add(this.GrpGetAll);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Margin = new System.Windows.Forms.Padding(4);
			this.MinimumSize = new System.Drawing.Size(1024, 640);
			this.Name = "FrmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "百度贴吧头像提取器";
			this.GrpGetAll.ResumeLayout(false);
			this.GrpGetAll.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.NumRankStart)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumRankEnd)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NumColumnCount)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PicCard)).EndInit();
			this.GrpMessage.ResumeLayout(false);
			this.GrpView.ResumeLayout(false);
			this.StsAbout.ResumeLayout(false);
			this.StsAbout.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox GrpGetAll;
		private System.Windows.Forms.PictureBox PicCard;
		private System.Windows.Forms.GroupBox GrpMessage;
		private System.Windows.Forms.GroupBox GrpView;
		private System.Windows.Forms.ProgressBar ProcBar;
		private System.Windows.Forms.TextBox TxtPath;
		private System.Windows.Forms.RichTextBox RtxMessage;
		private System.Windows.Forms.Button BtnDir;
		private System.Windows.Forms.FolderBrowserDialog FbrDir;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.NumericUpDown NumColumnCount;
		private System.Windows.Forms.ComboBox CbxTemplate;
		private System.Windows.Forms.CheckBox ChkBig;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.NumericUpDown NumRankEnd;
		private System.Windows.Forms.NumericUpDown NumRankStart;
		private System.Windows.Forms.TextBox TxtTiebaName;
		private System.Windows.Forms.Label LabTieba;
		private System.Windows.Forms.Button BtnGetAll;
		private System.Windows.Forms.StatusStrip StsAbout;
		private System.Windows.Forms.ToolStripStatusLabel TxtVersion;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.ToolStripStatusLabel TxtAuthor;
		private System.Windows.Forms.ToolStripStatusLabel TxtDate;
		private System.Windows.Forms.ToolStripStatusLabel TxtAbout;
	}
}

