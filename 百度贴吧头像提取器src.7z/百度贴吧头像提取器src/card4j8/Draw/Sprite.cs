﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Collections.Generic;
using System.Drawing;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {
	
	/// <summary>
	/// 精灵信息
	/// </summary>
	public abstract class Sprite {

		public int Z { get; set; }
		public int X { get; set; }
		public int Y { get; set; }
		public int W { get; set; }
		public int H { get; set; }
		
		/// <summary>
		/// 是否显示的逻辑对象
		/// </summary>
		protected List<Logic> _loginList = new List<Logic>();

		/// <summary>
		/// 图片路径设置
		/// </summary>
		public abstract string Path { set; }

		/// <summary>
		/// 叉烧包
		/// </summary>
		private readonly static SolidBrush ERROR_BRUSH = new SolidBrush(Color.FromArgb(255, 192, 192, 192));

		/// <summary>
		/// 初始化
		/// </summary>
		/// <param name="cfg">Sprite配置节</param>
		/// <param name="dirPath">模板文件夹路径</param>
		public Sprite(XElement cfg, string dirPath) {
			Z = cfg.GetInt("z");
			Path = dirPath + "\\" + cfg.GetString("path");
			XElement xRect = cfg.Element("rectangle");
			X = xRect.GetInt("x");
			Y = xRect.GetInt("y");
			W = xRect.GetInt("w");
			H = xRect.GetInt("h");
			var xLogicList = cfg.Elements("logic");
			foreach(var xLogic in xLogicList) {
				_loginList.Add(new Logic() {
					PropertyName = xLogic.GetString("property"),
					Min = xLogic.GetInt("min", int.MinValue),
					Max = xLogic.GetInt("max", int.MaxValue),
					Equal = xLogic.GetString("equal", null)
				});
			}
		}

		/// <summary>
		/// 绘制自身
		/// </summary>
		/// <param name="g">画布</param>
		/// <param name="user">用户信息</param>
		public void Draw(Graphics g, UserInfo user = null) {
			if(_isStep(user)) {
				return;
			}
			try {
				_drawImage(g, user);
			} catch {
				// 绘制叉烧包
				g.FillRectangle(ERROR_BRUSH, X, Y, W, H);
			}
		}

		protected abstract void _drawImage(Graphics g, UserInfo user);

		/// <summary>
		/// 绘制单张图片
		/// </summary>
		/// <param name="g"></param>
		/// <param name="map"></param>
		protected void _drawImage(Graphics g, Bitmap bitmap = null) {
			int w = W == 0 ? (bitmap == null ? 100 : bitmap.Width) : W;
			int h = H == 0 ? (bitmap == null ? 100 : bitmap.Height) : H;
			// 绘制图像
			g.DrawImage(bitmap, X, Y, w, h);
		}

		/// <summary>
		/// 判断是否跳过绘制
		/// </summary>
		/// <param name="user">用户信息</param>
		/// <returns>结果</returns>
		private bool _isStep(UserInfo user) {
			foreach(var logic in _loginList) {
				if(!logic.IsShow(user)) {
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// 工厂方法用
		/// </summary>
		protected Sprite() { }
	}
}
