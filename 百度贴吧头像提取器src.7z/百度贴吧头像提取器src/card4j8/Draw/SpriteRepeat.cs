﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Drawing;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {

	public class SpriteRepeat : SpriteDefault {

		public Point Offset { get; set; }

		public int Times { get; set; }

		public SpriteRepeat(XElement cfg, string dirPath)
			: base(cfg, dirPath) {
			Times = cfg.GetInt("times");
			var xOffset = cfg.Element("offset");
			Offset = new Point {
				X = xOffset.GetInt("x"),
				Y = xOffset.GetInt("y")
			};
		}

		protected override void _drawImage(Graphics g, UserInfo user) {
			for(int i = 0; i < Times; i++) {
				g.DrawImage(_bitmap, 
					X + i * Offset.X,
					Y + i * Offset.Y,
					W == 0 ? _bitmap.Width : W,
					H == 0 ? _bitmap.Height : H);
			}
		}
	}
}
