﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {

	public class SpriteLoop : Sprite {

		/// <summary>
		/// 图片列表
		/// </summary>
		protected List<Bitmap> _bitMapList = new List<Bitmap>();

		/// <summary>
		/// 路径设置图片读取
		/// </summary>
		public override string Path {
			set {
				string[] paths = Directory.GetFiles(value, "*.png");
				if(paths == null || paths.Length == 0) {
					return;
				}
				foreach(var imgPath in paths) {
					var img = ImageUtil.ReadImage(imgPath);
					_bitMapList.Add(new Bitmap(img));
				}
			}
		}

		/// <summary>
		/// dynamic {
		/// 	PropertyName 属性名
		/// 	ModAdd 取余运算偏移量
		/// }
		/// </summary>
		private dynamic _loop;

		public SpriteLoop(XElement cfg, string dirPath)
			: base(cfg, dirPath) {
			var xLoop = cfg.Element("loop");
			_loop = new {
				PropertyName = xLoop.GetString("property"),
				ModAdd = xLoop.GetInt("modAdd"),
			};
		}

		protected override void _drawImage(Graphics g, UserInfo user) {
			int propertyValue = (int)user[_loop.PropertyName];
			propertyValue = propertyValue + _loop.ModAdd;
			propertyValue = Math.Abs(propertyValue);
			int idx = propertyValue % _bitMapList.Count;
			// 绘制图像
			_drawImage(g, _bitMapList[idx]);
		}

	}
}
