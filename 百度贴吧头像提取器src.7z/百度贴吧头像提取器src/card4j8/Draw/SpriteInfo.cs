﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {

	public class SpriteInfo : SpriteDefault {

		/// <summary>
		/// 字体
		/// </summary>
		private Font _font;

		/// <summary>
		/// 偏移量
		/// </summary>
		private Point _offset;

		/// <summary>
		/// 显示项目
		/// </summary>
		private List<dynamic> _itemList;

		/// <summary>
		/// 颜色
		/// </summary>
		private Brush _brush;

		/// <summary>
		/// 空值
		/// </summary>
		private const string NULL_VALUE = "？？？";

		public SpriteInfo(XElement cfg, string dirPath)
			: base(cfg, dirPath) {
			var xOffset = cfg.Element("offset");
			_offset = new Point (xOffset.GetInt("x"), xOffset.GetInt("y"));
			_font = _createFont(cfg.Element("font"));
			_brush = _createColor(cfg.Element("color"));
			_itemList = new List<dynamic>();
			foreach(var xItem in cfg.Elements("item")) {
				_itemList.Add(new {
					Label = xItem.GetString("label"),
					PropertyName = xItem.GetString("property")
				});
			}
		}

		protected override void _drawImage(Graphics g, UserInfo user = null) {
			for(int i = 0; i < _itemList.Count; i++) {
				string text = _itemList[i].Label;
				if(user == null) {
					text += NULL_VALUE;
				} else {
					text += user[_itemList[i].PropertyName] ?? NULL_VALUE;
				}
				g.DrawString(text, _font, _brush,
					new Point(
						X + i * _offset.X,
						Y + i * _offset.Y)
				);
			}
		}

		private Font _createFont(XElement xFont) {
			if(xFont == null) {
				return new Font("黑体", 16);
			}
			string[] styleNames = xFont.GetString("style").Split('|');
			FontStyle style = 0;
			foreach(string styleName in styleNames) {
				FontStyle userStyle;
				if (Enum.TryParse<FontStyle>(styleName, true, out userStyle)){
					style |= userStyle;
				}
			}
			return new Font(
				xFont.GetString("name"),
				xFont.GetInt("size"),
				style
			);
		}

		private Brush _createColor(XElement xColor) {
			if (xColor == null){
				return new SolidBrush(Color.Black);
			}
			Color color = Color.FromArgb(
				xColor.GetInt("alpha", byte.MaxValue),
				xColor.GetInt("red"),
				xColor.GetInt("green"),
				xColor.GetInt("blue")
			);
			SolidBrush brush = new SolidBrush(color);
			return brush;
		}
	}
}
