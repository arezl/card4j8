﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Xml.Linq;

namespace TsubasaWing.App.TiebaCard.Draw {
	
	/// <summary>
	/// 头像
	/// </summary>
	public class SpriteHead : SpriteDefault {

		public SpriteHead(XElement cfg, string dirPath)
			: base(cfg, dirPath) {
		}

		protected SpriteHead() { }

		/// <summary>
		/// 空模板时，只输出头像
		/// </summary>
		/// <returns></returns>
		public static SpriteHead OnlyHead() {
			return new SpriteHead { 
				X = 0,
				Y = 0,
				W = 100,
				H = 100
			};
		}
	}
}
