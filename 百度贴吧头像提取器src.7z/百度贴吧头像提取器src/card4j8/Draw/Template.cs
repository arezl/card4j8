﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {
	
	/// <summary>
	/// 用户模板
	/// </summary>
	public class Template {

		/// <summary>
		/// 模板配置文件名
		/// </summary>
		public const string TEMPLATE_CONFIG_FILE_PATH = "config.xml";

		/// <summary>
		/// 模板名
		/// </summary>
		public string Name { get; private set; }

		/// <summary>
		/// 用户头像精灵
		/// </summary>
		public SpriteHead Head { get; set; }

		/// <summary>
		/// 宽度
		/// </summary>
		private int _width;

		/// <summary>
		/// 高度
		/// </summary>
		private int _height;

		/// <summary>
		/// 精灵列表
		/// </summary>
		public List<Sprite> AllSprite { get; private set; }

		/// <summary>
		/// 空模板
		/// </summary>
		public Template() {
			Name = "无";
			Head = SpriteHead.OnlyHead();
			_width = 100;
			_height = 100;
			AllSprite = new List<Sprite> { Head };
		}

		/// <summary>
		/// 初始化
		/// </summary>
		/// <param name="dirPath">模板路径</param>
		public Template(string dirPath) {
			int spriteId = 1;
			try {
				AllSprite = new List<Sprite>();
				var root = XDocument.Load(string.Format("{0}\\{1}", dirPath,
						Consts.TEMPLATE_CONFIG_FILE_PATH)).Root;
				Name = root.Attribute("name").Value;
				foreach(var spriteCfg in root.Elements("sprite")) {
					string type = spriteCfg.GetString("type", "Default");
					string typeName = "TsubasaWing.App.TiebaCard.Draw.Sprite{0}";
					var spriteType = Type.GetType(string.Format(typeName, type));
					var constructor = spriteType.GetConstructor(
							new Type[] { typeof(XElement), typeof(string) });
					var sprite = (Sprite)constructor.Invoke(
							new object[] { spriteCfg, dirPath });
					if(type == "Head") {
						Head = (SpriteHead)sprite;
					}
					AllSprite.Add(sprite);
					spriteId++;
				}
				// 获得最大面积精灵
				var maxArea = AllSprite.OrderBy(sp => sp.X * sp.Y).ToList<Sprite>()[0];
				// 模板总面积
				_width = maxArea.W;
				_height = maxArea.H;
				// 按照Z排序
				AllSprite = AllSprite.OrderBy(sp => sp.Z).ToList<Sprite>();
			} catch {
				Printer.Error("解析模板「{0}」时，出错：", Name ?? "?");
				Printer.Error("sprite：{0}：", spriteId);
				throw;
			}
		}

		/// <summary>
		/// 使用模板生成当前用户卡片
		/// </summary>
		/// <param name="user">用户信息</param>
		/// <returns>生成后的图片</returns>
		public Bitmap CreateCard(UserInfo user = null) {
			// 按照背景尺寸创建图像
			Bitmap map = new Bitmap(_width, _height);
			// 创建画布
			Graphics g = Graphics.FromImage(map);
			g.InterpolationMode = InterpolationMode.NearestNeighbor;
			g.PixelOffsetMode = PixelOffsetMode.Half;
			// 绘制全部精灵
			foreach(Sprite spt in AllSprite) {
				spt.Draw(g, user);
			}
			// 保存
			if(user != null && !string.IsNullOrEmpty(user.ImagePath)) {
				map.Save(user.ImagePath);
			}
			return map;
		}

		/// <summary>
		/// 画面显示用模板名
		/// </summary>
		/// <returns>模板名</returns>
		public override string ToString() {
			return Name;
		}
	}
}
