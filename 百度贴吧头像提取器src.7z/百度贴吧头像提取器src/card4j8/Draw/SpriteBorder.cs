﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {

	/// <summary>
	/// 多图片
	/// </summary>
	public class SpriteBorder : Sprite {
		
		/// <summary>
		/// 边框素材
		/// </summary>
		private Dictionary<string, Bitmap> _bitMapList = new Dictionary<string, Bitmap>();

		/// <summary>
		/// 边框粗细
		/// </summary>
		private int _borderSize = 0;

		public override string Path {
			set {
				string[] paths = Directory.GetFiles(value, "*.png");
				if(paths == null || paths.Length == 0) {
					return;
				}
				foreach(var imgPath in paths) {
					FileInfo imgFile = new FileInfo(imgPath);
					var img = ImageUtil.ReadImage(imgPath);
					_bitMapList.Add(
						imgFile.Name.Replace(imgFile.Extension, ""), 
						new Bitmap(img)
					);
				}
			}
		}

		public SpriteBorder(XElement cfg, string dirPath)
				: base(cfg, dirPath) {
			_borderSize = cfg.GetInt("borderSize");
		}

		/// <summary>
		/// 原理详见：http://tieba.baidu.com/p/2039621772
		/// 不解释
		/// </summary>
		/// <param name="g">画板</param>
		/// <param name="user">用户信息</param>
		protected override void _drawImage(Graphics g, UserInfo user) {
			int innerWidth = W - (_borderSize << 1);
			int innerHeight = H - (_borderSize << 1);
			int bottomY = Y + H - _borderSize;
			int rightX = X + W - _borderSize;
			int centerX = X + _borderSize;
			int centerY = Y + _borderSize;
			g.DrawImage(_bitMapList["left_top"], X, Y, _borderSize, _borderSize);
			g.DrawImage(_bitMapList["top"], centerX, Y, innerWidth, _borderSize);
			g.DrawImage(_bitMapList["right_top"], rightX, Y, _borderSize, _borderSize);
			g.DrawImage(_bitMapList["left"], X, centerY, _borderSize, innerHeight);
			g.DrawImage(_bitMapList["right"], rightX, centerY, _borderSize, innerHeight);
			g.DrawImage(_bitMapList["left_bottom"], X, bottomY, _borderSize, _borderSize);
			g.DrawImage(_bitMapList["bottom"], centerX, bottomY, innerWidth, _borderSize);
			g.DrawImage(_bitMapList["right_bottom"], rightX, bottomY, _borderSize, _borderSize);
		}

	}
}
