﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using System.Drawing;
using System.Xml.Linq;
using TsubasaWing.App.TiebaCard.Entity;
using TsubasaWing.App.TiebaCard.Util;

namespace TsubasaWing.App.TiebaCard.Draw {

	/// <summary>
	/// 单图片
	/// </summary>
	public class SpriteDefault : Sprite {

		/// <summary>
		/// 图片对象
		/// </summary>
		protected Bitmap _bitmap;

		/// <summary>
		/// 设置图片路径
		/// </summary>
		public override string Path {
			set {
				var img = ImageUtil.ReadImage(value);
				if(img != null) {
					_bitmap = new Bitmap(img);
				}
			}
		}

		public SpriteDefault(XElement cfg, string dirPath)
			: base(cfg, dirPath) {}

		/// <summary>
		/// 绘制单张图片
		/// </summary>
		/// <param name="g"></param>
		/// <param name="map"></param>
		protected override void _drawImage(Graphics g, UserInfo user) {
			_drawImage(g, _bitmap);
		}

		protected SpriteDefault() { }
	}
}
