﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
using TsubasaWing.App.TiebaCard.Entity;

namespace TsubasaWing.App.TiebaCard.Draw {
	
	/// <summary>
	/// 显示逻辑
	/// </summary>
	public class Logic {
		
		/// <summary>
		/// 用于判断的用户属性的属性名
		/// </summary>
		public string PropertyName { get; set; }

		/// <summary>
		/// 条件最大值
		/// </summary>
		public int Max { get; set; }

		/// <summary>
		/// 条件最小值
		/// </summary>
		public int Min { get; set; }

		/// <summary>
		/// 条件相等值
		/// </summary>
		public string Equal { get; set; }

		/// <summary>
		/// 判断图片是否显示
		/// </summary>
		/// <param name="user">用户信息</param>
		/// <returns>是否显示</returns>
		public bool IsShow(UserInfo user) {
			if(user == null) {
				return false;
			}
			object value = user[PropertyName];
			if(Equal != null && (value == null || Equal != value.ToString())) {
				return false;
			}
			if(value is int) {
				return Min <= (int)value && (int)value <= Max;
			}
			return false;
		}
	}
}
