﻿// 本工具由小翼开发，百度id：alwing
// 转载发布请著名出处，“百度java吧：alwing”。
// 该源码不得用于学习以外的其他任何目的。
// 修改，或重新编译，请保留版权信息。
//testgithug
using System;
using System.Windows.Forms;
using TsubasaWing.App.TiebaCard.Gui;

namespace TsubasaWing.App.TiebaCard {
	static class Program {
		[STAThread]
		static void Main() {
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new FrmMain());
		}
	}
}
